<?php

if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$name = 'Hide file information';
$description = 'Custom plugin';
$author = '<a href="http://forum.coppermine-gallery.net/index.php?action=profile;u=24278" rel="external" class="external">eenemeenemuu</a>';
$version = '0.1';
$plugin_cpg_version = array('min' => '1.5');

//EOF